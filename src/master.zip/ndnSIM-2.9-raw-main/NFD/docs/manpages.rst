.. _Manpages:

Manpages
========

.. toctree::
   manpages/nfd
   manpages/nfdc
   manpages/nfdc-status
   manpages/nfdc-face
   manpages/nfdc-route
   manpages/nfdc-cs
   manpages/nfdc-strategy
   manpages/nfd-asf-strategy
   manpages/nfd-status
   manpages/nfd-status-http-server
   schema
   manpages/ndn-autoconfig
   manpages/ndn-autoconfig.conf
   manpages/ndn-autoconfig-server
   local-prefix-discovery
   manpages/nfd-autoreg
   :maxdepth: 1
