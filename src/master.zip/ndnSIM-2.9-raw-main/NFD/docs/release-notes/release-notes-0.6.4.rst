NFD version 0.6.4
-----------------

Release date: October 19, 2018

This minor release fixes a regression introduced in version 0.6.3 that prevents NFD from
starting when RIB security configuration is enabled (:issue:`4759`).

For details of new and improved features since version 0.6.2, refer to the :ref:`release notes
of version 0.6.3 <v0.6.3>`.
